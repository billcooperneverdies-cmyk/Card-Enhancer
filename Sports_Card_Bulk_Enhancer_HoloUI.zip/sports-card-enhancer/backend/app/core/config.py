"""Application configuration settings."""
from pydantic_settings import BaseSettings
from typing import Optional
import os


class Settings(BaseSettings):
    """Application settings."""
    
    # App settings
    APP_NAME: str = "Sports Card Enhancer API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Server settings
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # File upload settings
    MAX_FILE_SIZE: int = 50 * 1024 * 1024  # 50MB
    MAX_BATCH_SIZE: int = 100  # Maximum number of files in a batch
    ALLOWED_EXTENSIONS: set = {".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp"}
    
    # Storage settings
    UPLOAD_DIR: str = "./uploads"
    OUTPUT_DIR: str = "./outputs"
    TEMP_DIR: str = "./temp"
    
    # Processing settings
    MAX_IMAGE_DIMENSION: int = 4096
    DEFAULT_OUTPUT_QUALITY: int = 95
    SUPPORTED_ENHANCEMENTS: list = [
        "blemish_removal",
        "sharpening",
        "color_correction",
        "contrast_enhancement",
        "noise_reduction",
        "upscaling"
    ]
    
    # AI Model settings
    USE_GPU: bool = True
    MODEL_CACHE_DIR: str = "./models"
    SWINIR_MODEL_PATH: Optional[str] = None
    REALESRGAN_MODEL_PATH: Optional[str] = None
    
    # Batch processing
    MAX_CONCURRENT_JOBS: int = 4
    JOB_TIMEOUT: int = 300  # 5 minutes
    
    # Redis settings (for production Celery)
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # External API settings (for hybrid approach)
    HUGGINGFACE_API_TOKEN: Optional[str] = None
    REPLICATE_API_TOKEN: Optional[str] = None
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()

# Ensure directories exist
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(settings.OUTPUT_DIR, exist_ok=True)
os.makedirs(settings.TEMP_DIR, exist_ok=True)
os.makedirs(settings.MODEL_CACHE_DIR, exist_ok=True)
